﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appAPI.Helper
{
    public static class ApplicationRole
    {
        public const string Admin = "Admin";
        public const string Employee = "Employee";
        public const string Designer = "Designer";
        public const string SuperAdmin = "Supper Admin";
        public const string Customer = "Customer";
    }
}
